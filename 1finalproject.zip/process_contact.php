<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "homestay";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$problem = $_POST['problem'];

// Prepare SQL statement
$sql = "INSERT INTO contacts (name, email, contact, problem) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $name, $email, $contact, $problem);

// Execute SQL statement
if ($stmt->execute()) {
    echo "Message sent successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$stmt->close();
$conn->close();
?>
