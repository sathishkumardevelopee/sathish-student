<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            
        }
        .container {

            max-width: 400px;
            margin: 100px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        input[type="text"], input[type="email"], select, textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
        }
        input[type="submit"] {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<?php include("nav.php")?>
    <div class="container">
        <center><h2>Contact Us</h2></center>
        <form action="submit_contact.php" method="POST">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" pattern="[A-Za-zÀ-ÿ-' ]+" title="Please enter a valid name" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter a valid email address" required>
            <label for="contact">Contact:</label>
            <input type="tel" id="contact" name="contact" pattern="[0-9]{10,}" title="Please enter a valid contact number with at least 10 digits" required>
            <br><br>
            <label for="problem_type">Type of Problem:</label><br>
            <select id="problem_type" name="problem_type" required>
                <option value="">Select</option>
                <option value="Technical Issue">Technical Issue</option>
                <option value="Billing Inquiry">Billing Inquiry</option>
                <option value="Feedback">Feedback</option>
                <option value="Other">Other</option>
            </select>
            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="4" required></textarea>
            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>
