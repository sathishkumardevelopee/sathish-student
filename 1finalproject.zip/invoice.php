<?php
// Establish connection to MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "homestay";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve booking information using booking ID
$booking_id = $_GET['id'];
$sql = "SELECT * FROM bookings WHERE id=$booking_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Display invoice information
    echo "<h2>Booked successful thankyou </h2>";
    echo "<p>Name: " . $row['name'] . "</p>";
    echo "<p>Email: " . $row['email'] . "</p>";
    echo "<p>Contact: " . $row['contact'] . "</p>";
    echo "<p>Booking Date: " . $row['booking_date'] . "</p>";
    echo "<p>Check In: " . $row['check_in'] . "</p>";
    echo "<p>Check Out: " . $row['check_out'] . "</p>";
} else {
    echo "Booking not found.";
}

$conn->close();
?>
