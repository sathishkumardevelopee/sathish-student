<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>gallery Document</title>

    <link rel="stylesheet" href="./assert/css/gallerystyle.css">
</head>

<body>
    <?php include("nav.php")?>
    <div class="container-fluid containerrr p-0">
        <!-- <div class="container"> -->
        <h1>GALLERY</h1>
        <div class="container image-containerrr">
           
        <div> 
            <div class="image"><img src="./galleryimg/home1.jpeg" alt=""></div><br>
            <details>
  <summary>Home 1 Details</summary>
  <p>Holiday Rental House
5 Km from Pondicherry Bus stand, 4.5 Km from Pondicherry Beach, 1 Km from Auroville. Auroville beach just in 3 km.
Free Wi-Fi, AC Room, Bathtub, shower, Kitchen with cooking accessories. Pleasant and Happy Home stay in Pondicherry.
Right Place to stay with family and enjoy the incredible Pondicherry.
House Rules
Pet-friendlyKid friendlySmoking allowed
Bedrooms
1 Super King1 Single
Bathrooms
1 Attached (ensuite)
</p>
</details><br>
         </div>


            <div>
              <div class="image"><img src="./galleryimg/home2.jpeg" alt=""></div><br>
            <details>
  <summary>Home 2 Details</summary>
  <p>
    Address
No 18, New Street Vinoba, Saram, Pondicherry - 605013 (Near Hotel Annamalai)
</p>
</details><br>
             </div>



           <div>
          <div class="image"><img src="./galleryimg/home3.jpeg" alt="">></div><br><details>
  <summary>Home 3 Details</summary>
  <p>Address
House Number .29, Swarna Bhoomi Avenue, 1 St Main Road, ECR Main Road, Kottakuppam, Pondicherry - 605104 (Near Serinity Beach)
</p>
</details><br>
           </div>


           <div>
           <div class="image"><img src="./galleryimg/home4.jpeg" alt=""></div><br><details>
  <summary>Home 4 Details</summary>
  <p>Address
No., Aurovil Main Road, Auroville, Pondicherry - 605101
</p>
</details><br>
           </div>



            <div>
            <div class="image"><img src="./galleryimg/home5.jpeg" alt=""></div><br><details>
  <summary>Home 5 Details</summary>
  <p>Address
No., Aurovil Main Road, Auroville, Pondicherry - 605101
</p>
</details><br>
            </div>


            <div>
            <div class="image"><img src="./galleryimg/home6.jpeg" alt=""></div><br><details>
  <summary>Home 6 Details</summary>
  <p>Address
No 18, New Street Vinoba, Saram, Pondicherry - 605013 (Near Hotel Annamalai)
</p>
</details><br>
            </div>



            <div>
            <div class="image"><img src="./galleryimg/home7.jpeg" alt=""></div><br><details>
  <summary>Home 7 Details</summary>
  <p>Address
No.08, Kali Amman Koil Street, Poniampet, White Town, Pondicherry - 605001 (Near By Rock Beach)
</p>
</details><br>
            </div>



            <div>
            <div class="image"><img src="./galleryimg/home8.jpeg" alt=""></div><br><details>
  <summary>Home 8 Details</summary>
  <p>HAddress
No 60, Miraambagai Garden, Auroville, Pondicherry - 605101 (Old Aurovile)
</p>
</details><br>
            </div>


           <div>
           <div class="image"><img src="./galleryimg/home9.jpeg" alt=""></div><br><details>
  <summary>Home 9 Details</summary>
  <p>Address
No 43, SV Patel Salai, Heritage Town, Pondicherry - 605001 (Near Rock Beach)
</p>
</details><br>



        </div>
           </div>

        <div class="popup-image">
            <!-- <span>&times;</span> -->
            <img src="./galleryimg/image1.jpg" alt="">
        </div>
    </div>




    <div class="container-fluid p-0 footerr">

        <h5>HOMESTAY</h5>
        <h6>12'th Cross Street Anna Nagar, Pondicherry 605005 India</h6>
        <h6>Phone: +91-8098299921</h6>
        <h6>WhatsApp: +91-8098299921</h6>
    </div>

    <script src="./assert/js/gallery.js"></script>
</body>

</html>