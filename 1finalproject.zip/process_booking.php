<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "homestay";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from booking page
$name = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$booking_date = $_POST['booking_date'];
$check_in = $_POST['check_in'];
$check_out = $_POST['check_out'];

// Insert data into database
$sql = "INSERT INTO bookings (name, email, contact, booking_date, check_in, check_out)
        VALUES ('$name', '$email', '$contact', '$booking_date', '$check_in', '$check_out')";

if ($conn->query($sql) === TRUE) {
    echo "Booking successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
