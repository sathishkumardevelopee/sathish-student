<!DOCTYPE html>
<html>
<head>
    <title>User booking Details</title>
    <style>
        /* Inline CSS */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h2 {
            color: black;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        a {
            text-decoration: none;
            color: #007bff;
            cursor: pointer;
        }
        a:hover {
            text-decoration: underline;
        }
        .btn {
            padding: 8px 20px;
            background-color: #dc3545;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
        }
        .btn-logout {
            background-color: #007bff;
        }
         /* body { */
          /* background-image: url("galleryimg/view.jpg"); */
          /* background-repeat: no-repeat; */
          /* background-size: cover; */
        /* } */
    </style>
</head>
<body>
    <div class="container">
        <h2>User Details</h2>
        <table>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Booking Date</th>
                <th>Check-in Date</th>
                <th>Check-out Date</th>
                <th>Action</th>
            </tr>
            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "homestay";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch user bookings from database
            $sql = "SELECT * FROM bookings";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['contact'] . "</td>";
                    echo "<td>" . $row['booking_date'] . "</td>";
                    echo "<td>" . $row['check_in'] . "</td>";
                    echo "<td>" . $row['check_out'] . "</td>";
                    echo "<td><a href='delete_booking.php?id=".$row['id']."' class='btn'>Delete</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No bookings found.</td></tr>";
            }

            $conn->close();
            ?>
        </table>
        <br>
        <a href="bookinglogout.php" class="btn btn-logout">Logout</a>
    </div>
</body>
</html>
