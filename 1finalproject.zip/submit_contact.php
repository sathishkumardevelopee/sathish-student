<?php
// Establish connection to MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "homestay";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$problem_type = $_POST['problem_type'];
$message = $_POST['message'];

// SQL query to insert data into table
$sql = "INSERT INTO contact_details (name, email, contact, problem_type, message) VALUES ('$name', '$email', '$contact', '$problem_type', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
