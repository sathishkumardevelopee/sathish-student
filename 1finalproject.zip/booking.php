<!DOCTYPE html>
<html>
<head>
    <title>Booking Page</title>
    <style>
        /* Inline CSS */
        body {
            font-family: Arial, sans-serif;
            
        }
        .container {

            max-width: 400px;
            margin: 100px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .custom-button {
            background-color: green; /* Set background color */
            color: #fff; /* Set text color */
            padding: 10px 20px; /* Add padding for better appearance */
            border: none; /* Remove default button border */
            border-radius: 5px; /* Add border radius for rounded corners */
            cursor: pointer; /* Change cursor to pointer on hover */
        }
        /* Change button color on hover */
        .custom-button:hover {
            background-color: #0056b3;
        }

        .center-text {
            text-align: center;
        }
        /* body { */
          /* background-image: url("galleryimg/view.jpg"); */
          /* background-repeat: no-repeat; */
          /* background-size: cover; */
        /* } */

    </style>
</head>
<body>
<?php include("nav.php")?>

    <div class="container">
    <div class="center-text">
    <h2>BOOKING PAGE</h2>
</div>
        <form action="process_booking.php" method="post">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="name" id="name" name="name" pattern="[A-Za-z\s'-]+" title="Please enter a valid name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter a valid email address" required>
            </div>
            <div class="form-group">
                <label for="contact">Contact:</label>
              <input type="tel" id="contact" name="contact" pattern="[0-9]{10,}" title="Please enter a valid contact number with at least 10 digits" required>
            </div>
            <div class="form-group">
                <label for="booking_date">Booking Date:</label>
                <input type="date" id="booking_date" name="booking_date" required>
            </div>
            <div class="form-group">
                <label for="check_in">Check-in Date:</label>
                <input type="date" id="check_in" name="check_in" required>
            </div>
            <div class="form-group">
                <label for="check_out">Check-out Date:</label>
                <input type="date" id="check_out" name="check_out" required>
            </div>
            <center><button class="custom-button">book now</button></center>
        </form>
    </div>
</body>
</html>
