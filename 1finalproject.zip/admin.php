<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Booked Details</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Admin - Booked Details</h2>
        <table>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Booking Date</th>
            </tr>
            <?php
            // Connect to your database
            $servername = "localhost";
            $username = "";
            $password = "password";
            $dbname = "homestay";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Prepare and execute SQL query
            $sql = "SELECT name, email, contact, booking_date FROM booked_details";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row["name"]."</td>";
                    echo "<td>".$row["email"]."</td>";
                    echo "<td>".$row["contact"]."</td>";
                    echo "<td>".$row["booking_date"]."</td>";
                    echo "</tr>";
                }
            } else {
                echo "No booked details found.";
            }
            $conn->close();
            ?>
        </table>
    </div>
</body>
</html>