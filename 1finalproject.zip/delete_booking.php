<?php
// Check if booking ID is provided
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "homestay";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize input to prevent SQL injection
    $booking_id = $_GET['id'];

    // Delete booking from database
    $sql = "DELETE FROM bookings WHERE id = '$booking_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Booking deleted successfully!";
    } else {
        echo "Error deleting booking: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Booking ID not provided!";
}
?>
