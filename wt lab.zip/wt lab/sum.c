#include<stdio.h>
#include<conio.h>
int main()
{
    int num1, num2, sum;
    Printf("Enter The First Number:");
    Scanf("%d",&num1);
    printf("Enter the Second Number:");
    Scanf("%d",&num2);

    sum=num1+num2;
    Prinf("Sum of First and Second Number is: ", &sum)
    return 0;
}