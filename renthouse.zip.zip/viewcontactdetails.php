<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Submit page details</title><br>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .logout-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .delete-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 6px 12px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            cursor: pointer;
        }
        .delete-btn:hover {
            background-color: #45a049;
        }
        .footer {
         margin-top: 5px;
        background-color: green;
          height: 150px;
          width: 100%;
          display: flex;
          text-align: center;
          justify-content: center;
           flex-direction: column;
            color: aliceblue;
             }

h5 {
    margin-top: 10px;
    font-weight: bold;
}

    </style>
</head>
<body>


<?php
// Establish connection to MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "renthouse";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete record if delete button is clicked
if(isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM contact_details WHERE id = $delete_id";
    if ($conn->query($sql) === TRUE) {
        echo "";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// SQL query to retrieve all contact details
$sql = "SELECT * FROM contact_details";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2> Contact Details</h2>";    
    echo "<table>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Problem Type</th>
                <th>Message</th>
                <th>date</th>
                <th>Action</th>
            </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".$row["name"]."</td>
                <td>".$row["email"]."</td>
                <td>".$row["contact"]."</td>
                <td>".$row["problem_type"]."</td>
                <td>".$row["message"]."</td>
                <td>".$row["date"]."</td>
                <td><a href='viewcontactdetails.php?delete_id=".$row['id']."' class='delete-btn'>Delete</a></td>
            </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>

<a href="contactlogout.php" class="logout-btn">Logout</a><br><br><br><br><br><br><br><br><br><br>

<div class="container-fluid p-0 footer">

        <h5> HOMESTAY</h5>
        <h6>12'th Cross Street Anna Nagar, Pondicherry 605005 India</h6>
        <h6>Phone: +91-8098299921</h6>
        <h6>WhatsApp: +91-8098299921</h6>
    </div>

</body>
</html>
