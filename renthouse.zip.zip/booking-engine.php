<?php

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include("config/config.php");

if (isset($_POST['book_property'])) {

    if (isset($_SESSION["email"])) {
        global $db, $property_id;
        $u_email = $_SESSION["email"];

        $property_id = $_GET['property_id'];

        $sql = "SELECT * FROM tenant where email='$u_email'";
        $query = mysqli_query($db, $sql);

        if (mysqli_num_rows($query) > 0) {
            while ($rows = mysqli_fetch_assoc($query)) {
                $tenant_id = $rows['tenant_id'];

                $sql1 = "UPDATE add_property SET booked='1' WHERE property_id='$property_id'";
                $query1 = mysqli_query($db, $sql1);

                $sql2 = "INSERT INTO booking(property_id,tenant_id) VALUES ('$property_id','$tenant_id')";
                $query2 = mysqli_query($db, $sql2);

                if ($query2) {

                    $email = $rows['email'];
                    $msg = "Thank you Mr/Ms " . $rows['full_name'] . " for booking Property. Please visit the property location to view it personally.";
                    $recipient = $email;
                    $subject = "Property Booked";

                    // Initialize PHPMailer
                    $mail = new PHPMailer(true);
                    try {
                        //Server settings
                        $mail->isSMTP();
                        $mail->Host       = 'smtp.gmail.com'; // SMTP server
                        $mail->SMTPAuth   = true;
                        $mail->Username   = 'shobanbabu726@gmail.com'; // SMTP account username
                        $mail->Password   = 'qeax dtjy hfsi igxb';   // SMTP account password
                        $mail->SMTPSecure = 'tls'; // Enable TLS encryption
                        $mail->Port       = 587; // TCP port to connect to

                        //Recipients
                        $mail->setFrom('shobanbabu726@gmail.com', 'RentHouse');
                        $mail->addAddress('shobanbabu726@gmail.com','user');     // Add a recipient
                      
                        // Content
                        $mail->isHTML(true); // Set email format to HTML
                        $mail->Subject = 'sathish';
                        $mail->Body    = 'sathish mail';

                        $mail->send();

                        echo '<div class="container">
                        <div class="alert" role="alert">
                        <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span> 
                        <center><strong>Thank you for booking this property.</strong></center>
                        </div></div>';

                    } catch (Exception $e) {
                        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                    }
                }
            }
        }
    }
}
?>
