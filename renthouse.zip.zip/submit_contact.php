<?php
// Establish connection to MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "renthouse";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

// declare variable
$name = $_POST["name"];
$email = $_POST["email"];
$contact = $_POST["contact"];
$problem_type=$_POST["problem_type"];
$message=$_POST["message"];
$date = date("Y-m-d");


// Retrieve form data
// $name = $_POST['name'];
// $email = $_POST['email'];
// $contact = $_POST['contact'];
// $problem_type = $_POST['problem_type'];
// $message = $_POST['message'];
//     echo "New record created successfully";
// } else {
//     echo "Error: " . $sql . "<br>" . $conn->error;
// }

// $conn->close();

// SQL query to insert data into table
$sql = "INSERT INTO contact_details (name, email, contact, problem_type, message,date) 
VALUES ('$name', '$email', '$contact', '$problem_type', '$message','$date')";
if ($conn->query($sql) === TRUE) {


//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
                   
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'shobanbabu726@gmail.com';                     //SMTP username
    $mail->Password   = 'qeax dtjy hfsi igxb';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom($email, $name);
    $mail->addAddress($email);     //Add a recipient
    

    

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'thank you your feedback is sent successful in homestay contact page';
    $mail->Body    = 'your message succssful sent our mangenment .';
    $mail->AltBody = 'your message sccecessfull sent our mangenment  ';
   

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
 }
// ----------------------
?>





