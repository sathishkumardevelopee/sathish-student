<!DOCTYPE html>
<html>
<head>
    <title>Add Property Form</title>
</head>
<body>
    <h2>Add Property</h2>
    <form method="post" action="add_property_process.php">
        <label>Country:</label>
        <input type="text" name="country" required><br><br>
        
        <label>Province:</label>
        <input type="text" name="province" required><br><br>
        
        <label>Zone:</label>
        <input type="text" name="zone" required><br><br>
        
        <label>District:</label>
        <input type="text" name="district" required><br><br>
        
        <label>City:</label>
        <input type="text" name="city" required><br><br>
        
        <label>VDC/Municipality:</label>
        <input type="text" name="vdc_municipality" required><br><br>
        
        <label>Ward No:</label>
        <input type="number" name="ward_no" required><br><br>
        
        <label>Tole:</label>
        <input type="text" name="tole" required><br><br>
        
        <label>Contact No:</label>
        <input type="tel" name="contact_no" required><br><br>
        
        <label>Property Type:</label>
        <input type="text" name="property_type" required><br><br>
        
        <label>Estimated Price:</label>
        <input type="number" name="estimated_price" required><br><br>
        
        <label>Total Rooms:</label>
        <input type="number" name="total_rooms" required><br><br>
        
        <label>Bedroom:</label>
        <input type="number" name="bedroom" required><br><br>
        
        <label>Living Room:</label>
        <input type="number" name="living_room" required><br><br>
        
        <label>Kitchen:</label>
        <input type="number" name="kitchen" required><br><br>
        
        <label>Bathroom:</label>
        <input type="number" name="bathroom" required><br><br>
        
        <label>Booked:</label>
        <input type="checkbox" name="booked"><br><br>
        
        <label>Description:</label><br>
        <textarea name="description" rows="5" cols="50" required></textarea><br><br>
        
        <label>Latitude:</label>
        <input type="number" name="latitude" step="0.000001" required><br><br>
        
        <label>Longitude:</label>
        <input type="number" name="longitude" step="0.000001" required><br><br>
        
        <label>Owner ID:</label>
        <input type="number" name="owner_id" required><br><br>
        
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>
