<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection file
    include "owner/config.php"; // Replace "db_connection.php" with your actual file name

    // Escape user inputs for security
    $country = mysqli_real_escape_string($conn, $_POST['country']);
    $province = mysqli_real_escape_string($conn, $_POST['province']);
    $zone = mysqli_real_escape_string($conn, $_POST['zone']);
    $district = mysqli_real_escape_string($conn, $_POST['district']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $vdc_municipality = mysqli_real_escape_string($conn, $_POST['vdc_municipality']);
    $ward_no = mysqli_real_escape_string($conn, $_POST['ward_no']);
    $tole = mysqli_real_escape_string($conn, $_POST['tole']);
    $contact_no = mysqli_real_escape_string($conn, $_POST['contact_no']);
    $property_type = mysqli_real_escape_string($conn, $_POST['property_type']);
    $estimated_price = mysqli_real_escape_string($conn, $_POST['estimated_price']);
    $total_rooms = mysqli_real_escape_string($conn, $_POST['total_rooms']);
    $bedroom = mysqli_real_escape_string($conn, $_POST['bedroom']);
    $living_room = mysqli_real_escape_string($conn, $_POST['living_room']);
    $kitchen = mysqli_real_escape_string($conn, $_POST['kitchen']);
    $bathroom = mysqli_real_escape_string($conn, $_POST['bathroom']);
    $booked = isset($_POST['booked']) ? 1 : 0; // Checkbox value
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $latitude = mysqli_real_escape_string($conn, $_POST['latitude']);
    $longitude = mysqli_real_escape_string($conn, $_POST['longitude']);
    $owner_id = mysqli_real_escape_string($conn, $_POST['owner_id']);

    // Attempt to insert data into database
    $sql = "INSERT INTO add_property (country, province, zone, district, city, vdc_municipality, ward_no, tole, contact_no, property_type, estimated_price, total_rooms, bedroom, living_room, kitchen, bathroom, booked, description, latitude, longitude, owner_id) 
            VALUES ('$country', '$province', '$zone', '$district', '$city', '$vdc_municipality', '$ward_no', '$tole', '$contact_no', '$property_type', '$estimated_price', '$total_rooms', '$bedroom', '$living_room', '$kitchen', '$bathroom', '$booked', '$description', '$latitude', '$longitude', '$owner_id')";
    
    if (mysqli_query($conn, $sql)) {
        // If insertion successful, redirect to success page or display success message
        echo "Property added successfully!";
    } else {
        // If insertion failed, display error message
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close database connection
    mysqli_close($conn);
} else {
    // If the form is not submitted, redirect to the form page
    header("Location: addpro.php"); // Replace "add_property_form.php" with your actual file name
    exit();
}
?>
