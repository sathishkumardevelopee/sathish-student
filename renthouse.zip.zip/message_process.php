<?php
// Establish connection to MySQL
$servername = "localhost";
$username = "root";
$password = "";
$database = "renthouse";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL statement to insert message
$stmt = $conn->prepare("INSERT INTO messages (sender_name, sender_email, recipient_name, recipient_email, subject, message) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $sender_name, $sender_email, $recipient_name, $recipient_email, $subject, $message);

// Set parameters and execute
$sender_name = $_POST['sender_name'];
$sender_email = $_POST['sender_email'];
$recipient_name = $_POST['recipient_name'];
$recipient_email = $_POST['recipient_email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$stmt->execute();

echo "Message sent successfully!";

$stmt->close();
$conn->close();
?>
