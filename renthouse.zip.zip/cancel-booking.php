<?php
session_start();
include("config/config.php");

if(isset($_GET['property_id'])) {
    $property_id = $_GET['property_id'];
    $u_email = $_SESSION['email'];

    // Retrieve tenant ID based on email
    $sql_tenant = "SELECT * FROM tenant WHERE email='$u_email'";
    $result_tenant = mysqli_query($db, $sql_tenant);
    if(mysqli_num_rows($result_tenant) > 0) {
        $row_tenant = mysqli_fetch_assoc($result_tenant);
        $tenant_id = $row_tenant['tenant_id'];

        // Check if the booking exists for the given tenant and property
        $sql_booking = "SELECT * FROM booking WHERE tenant_id='$tenant_id' AND property_id='$property_id'";
        $result_booking = mysqli_query($db, $sql_booking);
        if(mysqli_num_rows($result_booking) > 0) {
            // Delete the booking
            $sql_delete_booking = "DELETE FROM booking WHERE tenant_id='$tenant_id' AND property_id='$property_id'";
            if(mysqli_query($db, $sql_delete_booking)) {
                // Update the add_property table to indicate that the property is not booked
                $sql_update_property = "UPDATE add_property SET booked = 0 WHERE property_id = '$property_id'";
                mysqli_query($db, $sql_update_property);

                // Booking canceled successfully
                echo "<script>alert('Booking canceled successfully');</script>";
                echo "<script>window.location.href = 'index.php';</script>"; // Redirect to your bookings page
                exit();
            } else {
                echo "<script>alert('Error canceling booking');</script>";
                echo "<script>window.location.href = 'index.php';</script>"; // Redirect to your bookings page
                exit();
            }
        } else {
            // Booking not found for the given tenant and property
            echo "<script>alert('Booking not found');</script>";
            echo "<script>window.location.href = 'index.php';</script>"; // Redirect to your bookings page
            exit();
        }
    } else {
        // Tenant not found
        echo "<script>alert('Tenant not found');</script>";
        echo "<script>window.location.href = 'index.php';</script>"; // Redirect to your bookings page
        exit();
    }
} else {
    // Property ID not provided
    echo "<script>alert('Property ID not provided');</script>";
    echo "<script>window.location.href = 'index.php';</script>"; // Redirect to your bookings page
    exit();
}
?>
