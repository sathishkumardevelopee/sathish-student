<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Property</title>
    <style>
        /* Basic styling for layout */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
        }
        .form-group input, 
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            resize: vertical;
        }
        .form-group button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .add-property-link {
            text-align: center;
            margin-top: 20px;
        }
        .add-property-link a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add Property</h2>
    <form action="#" method="post">
        <div class="form-group">
            <label for="country">Country:</label>
            <input type="text" id="country" name="country">
        </div>
        <div class="form-group">
            <label for="province">Province/State:</label>
            <input type="text" id="province" name="province">
        </div>
        <div class="form-group">
            <label for="zone">Zone:</label>
            <input type="text" id="zone" name="zone">
        </div>
        <div class="form-group">
            <label for="district">District:</label>
            <input type="text" id="district" name="district">
        </div>
        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" id="city" name="city">
        </div>
        <div class="form-group">
            <label for="municipality">VDC/Municipality:</label>
            <input type="text" id="municipality" name="municipality">
        </div>
        <div class="form-group">
            <label for="ward">Ward No:</label>
            <input type="number" id="ward" name="ward">
        </div>
        <div class="form-group">
            <label for="tole">Tole:</label>
            <input type="text" id="tole" name="tole">
        </div>
        <div class="form-group">
            <label for="contact">Contact No:</label>
            <input type="tel" id="contact" name="contact">
        </div>
        <div class="form-group">
            <label for="type">Property Type:</label>
            <select id="type" name="type">
                <option value="house">House</option>
                <option value="apartment">Apartment</option>
                <option value="land">Land</option>
            </select>
        </div>
        <div class="form-group">
            <label for="price">Estimated Price:</label>
            <input type="number" id="price" name="price">
        </div>
        <h3>Details</h3>
        <div class="form-group">
            <label for="rooms">Total Number of Rooms:</label>
            <input type="number" id="rooms" name="rooms">
        </div>
        <div class="form-group">
            <label for="bathrooms">Number of Bathrooms:</label>
            <input type="number" id="bathrooms" name="bathrooms">
        </div>
        <div class="form-group">
            <label for="living-room">Number of Living Rooms:</label>
            <input type="number" id="living-room" name="living-room">
        </div>
        <div class="form-group">
            <label for="kitchen">Number of Kitchens:</label>
            <input type="number" id="kitchen" name="kitchen">
        </div>
        <div class="form-group">
            <label for="bathroom-washroom">Number of Bathrooms & Washrooms:</label>
            <input type="number" id="bathroom-washroom" name="bathroom-washroom">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="5"></textarea>
        </div>
        <div class="form-group">
            <label for="latitude">Latitude:</label>
            <input type="text" id="latitude" name="latitude">
        </div>
        <div class="form-group">
            <label for="longitude">Longitude:</label>
            <input type="text" id="longitude" name="longitude">
        </div>
        <div class="form-group">
            <label for="photos">Photos:</label>
            <input type="file" id="photos" name="photos" accept="image/*" multiple>
        </div>
        <div class="form-group">
            <button type="submit">Add Property</button>
        </div>
    </form>
</div>

<div class="add-property-link">
    <a href="index.php">Back to Index</a>
</div>

</body>
</html>
